# READY2EAT
Team project I worked on during the MDS course at the Uni
